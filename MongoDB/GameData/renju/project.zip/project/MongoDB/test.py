from pymongo import MongoClient
import random
client = MongoClient()
db = client.gomukuDB
coll =  db.Gamedata
print coll.count()
print random.randint(1,99)